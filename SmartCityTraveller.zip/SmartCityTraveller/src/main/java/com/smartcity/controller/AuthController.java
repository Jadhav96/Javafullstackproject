package com.smartcity.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smartcity.model.User;
import com.smartcity.service.authService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {
	@Autowired
	private authService service;
	
	@GetMapping("/")
	public String logIn() {
		return "Login";
	}
	
	@GetMapping("/signup")
	public String signUp() {
		return "Signup";
	}
	
	@PostMapping("/register")
	public String registerUser(@ModelAttribute("user") User user, Model model) {
		boolean isRegistered = service.registerUser(user);
		if(isRegistered) {
			model.addAttribute("message","User Registered Successfully...");
			return "Login";
		}
		model.addAttribute("message","Username Already Exists....");
		return "Signup";
	}
	
	// Process login
    @PostMapping("/login")
    public String processLogin(@ModelAttribute User user, HttpSession session, Model model) {
    	boolean isAuthenticated  = service.authenticateUser(user.getUsername(), user.getPassword());

        if (isAuthenticated) {
            session.setAttribute("username", user.getUsername());
            return "redirect:/home"; // Redirect to home
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "Login";
        }
    }
	
    @GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/?logout";
	}
}
