package com.smartcity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smartcity.model.City;
import com.smartcity.model.Place;
import com.smartcity.service.CategoryService;
import com.smartcity.service.CityService;
import com.smartcity.service.PlaceService;

import jakarta.servlet.http.HttpSession;


@Controller
public class HomeController {

    @Autowired private CityService cityService;
    @Autowired private CategoryService categoryService;
    @Autowired private PlaceService placeService;

    @GetMapping("/home")
    public String home(HttpSession session) {
    	if(session.getAttribute("username") == null) {
    		return "redirect:/";
    	}
        return "index";
    }

    @PostMapping("/search")
    public String searchCity(@RequestParam String city, HttpSession session, Model model) {
    	if(session.getAttribute("username") == null) {
    		return "redirect:/";
    	}
    	City c = cityService.getOrCreateCity(city);
        model.addAttribute("city", city);
        model.addAttribute("categories", categoryService.getAll());
        return "categories";
    }

    @GetMapping("/city/{city}/category/{category}")
    public String showPlaces(@PathVariable String city, @PathVariable String category,  HttpSession session, Model model) {
    	if(session.getAttribute("username") == null) {
    		return "redirect:/";
    	}
    	List<Place> places = placeService.getPlacesByCityAndCategory(city, category);
        model.addAttribute("places", places);
        model.addAttribute("city", city);
        model.addAttribute("category", category);
        return "places";
    }

    @GetMapping("/map")
    public String showMap(@RequestParam String mapEmbedUrl, HttpSession session, Model model) {
    	if(session.getAttribute("username") == null) {
    		return "redirect:/";
    	}
        model.addAttribute("url", mapEmbedUrl);
        return "map";
    }
}
