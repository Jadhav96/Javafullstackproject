package com.smartcity.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Place {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

	@Column(length = 1000)
    private String mapEmbedUrl;

    @ManyToOne
    private City city;

    @ManyToOne
    private Category category;

    public Place() {
	}
    
	public Place(Long id, String name, String mapEmbedUrl, City city, Category category) {
		super();
		this.id = id;
		this.name = name;
		this.mapEmbedUrl = mapEmbedUrl;
		this.city = city;
		this.category = category;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMapEmbedUrl() {
		return mapEmbedUrl;
	}

	public void setMapEmbedUrl(String mapEmbedUrl) {
		this.mapEmbedUrl = mapEmbedUrl;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
}
