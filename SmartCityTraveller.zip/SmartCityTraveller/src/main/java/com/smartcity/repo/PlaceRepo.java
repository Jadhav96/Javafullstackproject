package com.smartcity.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartcity.model.Place;

public interface PlaceRepo extends JpaRepository<Place, Long> {
    List<Place> findByCityNameIgnoreCaseAndCategoryNameIgnoreCase(String city, String category);
}
