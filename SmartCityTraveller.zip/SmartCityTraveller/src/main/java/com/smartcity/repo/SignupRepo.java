package com.smartcity.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartcity.model.User;


public interface SignupRepo extends JpaRepository<User,Integer>{
	User findByUsername(String username); 
}
