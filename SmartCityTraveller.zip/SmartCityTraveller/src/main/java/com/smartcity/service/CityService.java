package com.smartcity.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.model.City;
import com.smartcity.repo.CityRepo;

@Service
public class CityService {
    @Autowired
    private CityRepo cityRepo;

    public City getOrCreateCity(String name) {
        return cityRepo.findByNameIgnoreCase(name).orElseGet(() -> cityRepo.save(new City(name)));
    }
}
