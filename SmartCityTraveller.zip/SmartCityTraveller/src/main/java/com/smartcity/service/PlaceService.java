package com.smartcity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.model.Place;
import com.smartcity.repo.PlaceRepo;

@Service
public class PlaceService {
    @Autowired
    private PlaceRepo placeRepo;

    public List<Place> getPlacesByCityAndCategory(String city, String category) {
        return placeRepo.findByCityNameIgnoreCaseAndCategoryNameIgnoreCase(city, category);
    }
}
