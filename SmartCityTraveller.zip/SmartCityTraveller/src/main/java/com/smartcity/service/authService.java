package com.smartcity.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.model.User;
import com.smartcity.repo.SignupRepo;

@Service
public class authService {

	@Autowired
	private SignupRepo repo;
	
	public boolean registerUser(User user) {
		User user1 = repo.findByUsername(user.getUsername());
		if(user1==null) {
			repo.save(user);
			return true;
		}else {
			return false;
		}
	}
	
	public boolean authenticateUser(String username, String password) {
			User user = repo.findByUsername(username);
			
			if(user!=null && user.getPassword().equals(password)) {
				return true;
			}
				return false;
	}
}
