package com.smartcity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartCityTravellerApplicationTests {

	@Test
	void contextLoads() {
	}

}
